Welcome to the Sonique Skinmaker X Skinpack version 0.51
(C) 1999 Vovoid Software & Multimedia (http://www.vovoid.com)


  The Sonique Skinmaker X executable (ssx.exe) is by default 
  installed into the Sonique directory. It's recommended that 
  it uses this directory since it's supporting the 
  Sonique directory structure. (The help files etc.)

  If you find a bug or have a question that is skin-related, please
  do not hesitate to e-mail: ssxsupport@sonique.com

  Do NOT use this adress to correspond about general Sonique behaviour.


Version info:
- 0.51 [ 11/5 2000 ]
  * Fixed Bug: Nav Volume Knob (wouldn't load...)
- 0.50 [ 2/5 2000 ]
  * Fixed Bug 1# - When entering advanced->Manual Ini Editor the
    color values was inverted. (Red<->Blue)
  * Fixed Bug 2# - Test Skin made SSX crash A LOT. Fixed it and
    added some nice ui to display that Sonique is launching the skin.
- 0.44 
  * Added support for the special Nav Mode Volume Animation
    (The Mid Mode is still the default one if you want both 
	to be the same)
  * Fixed ~ and _ characters in all the edit boxes on the
    SSX->Info page.
  * Minor optimizations of the graphics engine
  * The default Sonique colors are now by default loaded
    upon creating new skin.
  * Default version number in the default ini file changed to
    105 for better compatibility (Sonique 1.05)
  * 

- 0.42 Beta 1
  First released version